import React from "react";
export default function DashboardPage() {
  return <div className="p-4 text-xl font-semibold">Halaman DashboardPage</div>;
}
