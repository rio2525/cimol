import React from "react";
export default function HistoryPage() {
  return <div className="p-4 text-xl font-semibold">Halaman HistoryPage</div>;
}
