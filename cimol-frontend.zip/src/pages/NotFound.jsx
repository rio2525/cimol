import React from "react";
export default function NotFound() {
  return <div className="p-4 text-xl font-semibold">Halaman NotFound</div>;
}
