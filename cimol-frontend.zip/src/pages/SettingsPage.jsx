import React from "react";
export default function SettingsPage() {
  return <div className="p-4 text-xl font-semibold">Halaman SettingsPage</div>;
}
