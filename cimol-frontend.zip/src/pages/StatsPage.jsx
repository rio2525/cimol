import React from "react";
export default function StatsPage() {
  return <div className="p-4 text-xl font-semibold">Halaman StatsPage</div>;
}
