import React from "react";
export default function UploadPage() {
  return <div className="p-4 text-xl font-semibold">Halaman UploadPage</div>;
}
